QuickClean = function(x,i)
{
  if(i==0)
  {
    x = x[complete.cases(x), ]
    return(x)
  }
  if(i==1)
  {
    checkcol = function(y)
    {
      if(is.numeric(y) == TRUE)
      {
        y[is.na(y)] = mean(y, na.rm = TRUE)
      }
      else
      {
        levels=unique(y)
        y[is.na(y)]=levels[which.max(tabulate(match(y, x = levels)))]
      }
      return(y)
    }
    x = lapply(x,checkcol)
    return(data.frame(x))
  }
}

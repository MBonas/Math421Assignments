QuickVisual = function(x, i)
{
  library(ggplot2)
  if(is.data.frame(x) & i==1)
  {
    x_cat = x[,sapply(x, is.factor)]
    checklevel = function(y)
    {
      l  = (length(unique(y)) < 5)
      return(l)
    }
    x_cat5 = x_cat[,sapply(x_cat, checklevel)]
    combin = combn(names(x_cat5), 2, simplify = TRUE)
    barcharts = function(z)
    {
      chart = ggplot(z) + geom_bar(mapping = aes(x=z[,1], fill=z[,2]), position = "dodge") + xlab(names(z[1])) + labs(fill = names(z[2]))
      return(chart)
    }
    printcharts = function(w)
    {
      barcharts(x_cat5[,w])
    }
    charts = apply(combin,2,printcharts)
    return(charts)
  }
  if(is.data.frame(x) & i==2)
  {
    for(i in 1:ncol(x))
    {
      for(j in 1:ncol(x))
      {
        if((class(x[[i]])) == "numeric")
        {
          if((class(x[[j]])) == "factor" & (length(unique(x[[j]]) < 5)))
          {
            print(ggplot(x) + geom_density(mapping = aes(x=x[[i]])) + facet_wrap(x[[j]]))
          }
        }
      }
    }
  }
  if(i==3)
  {
    x_num = x[,sapply(x, is.numeric)]
    combin = combn(names(x_num), 2, simplify = TRUE)
    barcharts = function(z)
    {
      chart = ggplot(z) + geom_point(mapping = aes(x=z[,1], y=z[,2])) + xlab(names(z[1])) + ylab(names(z[2]))
      return(chart)
    }
    printcharts = function(w)
    {
      barcharts(x_num[,w])
    }
    charts = apply(combin,2,printcharts)
    return(charts)
  }
}

QuickModel = function(x,i)
{
  library(ranger)
  library(caret)
  colnames(x)[i] = "target"
  myGrid = expand.grid(mtry = 2, splitrule = c("gini"), min.node.size = c(1:3))
  model = train(target~., x, method = "ranger", trControl = trainControl(method = "cv", number = 7), tuneGrid = myGrid)
  return(max(model$results$Accuracy))
}
